package com.example.totpshare

import android.content.Context
import android.net.Uri
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage

/** Reads QR/barcodes from a shared image and returns the first parseable TOTP payload. */
object QrImageProcessor {

    fun process(
        context: Context,
        imageUri: Uri,
        onResult: (ParsedTotp?) -> Unit
    ) {
        val image = try {
            InputImage.fromFilePath(context, imageUri)
        } catch (_: Exception) {
            onResult(null)
            return
        }

        val options = BarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
            .build()
        val scanner = BarcodeScanning.getClient(options)

        scanner.process(image)
            .addOnSuccessListener { barcodes ->
                val parsed = barcodes.asSequence()
                    .mapNotNull { it.rawValue?.trim() }
                    .mapNotNull(IntentHandler::parseText)
                    .firstOrNull()
                onResult(parsed)
            }
            .addOnFailureListener {
                onResult(null)
            }
            .addOnCompleteListener {
                scanner.close()
            }
    }
}
