package com.example.totpshare

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object AppNotificationManager {

    const val CHANNEL_ID = "totp_codes"
    const val ACTION_COPY_CODE = "com.example.totpshare.COPY_CODE"
    const val ACTION_COPY_SOURCE = "com.example.totpshare.COPY_SOURCE"

    private const val EXTRA_VALUE = "value"
    private const val EXTRA_NOTIFICATION_ID = "notification_id"

    fun createChannel(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            "eMaD 2FA",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Live eMaD 2FA verification codes"
        }
        manager.createNotificationChannel(channel)
    }

    fun show(context: Context, parsed: ParsedTotp) {
        if (!AppSettings(context).isEnabled()) return

        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) return

        // Start a foreground service so the notification can update the TOTP
        // code automatically every second, including when the app is in background.
        val serviceIntent = Intent(context, TotpLiveNotificationService::class.java).apply {
            action = TotpLiveNotificationService.ACTION_START
            putExtra("name", parsed.serviceName)
            putExtra("secret", parsed.secret)
            putExtra("source", parsed.source)
        }

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent)
        } else {
            context.startService(serviceIntent)
        }

        val code = TotpGenerator.generate(parsed.secret)
        val notificationId = (System.currentTimeMillis() and 0x7FFFFFFF).toInt()

        val copyCode = actionIntent(
            context,
            ACTION_COPY_CODE,
            code,
            notificationId
        )
        val copySource = actionIntent(
            context,
            ACTION_COPY_SOURCE,
            parsed.source,
            notificationId
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_emad2fa)
            .setContentTitle(parsed.serviceName)
            .setContentText(code)
            .setStyle(NotificationCompat.BigTextStyle().bigText(code))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .addAction(
                android.R.drawable.ic_menu_save,
                "نسخ الرمز",
                copyCode
            )
            .addAction(
                android.R.drawable.ic_menu_share,
                "نسخ المفتاح",
                copySource
            )
            .build()

        NotificationManagerCompat.from(context).notify(notificationId, notification)
    }

    fun stopLive(context: Context) {
        val stopIntent = Intent(context, TotpLiveNotificationService::class.java).apply {
            action = TotpLiveNotificationService.ACTION_STOP
        }
        context.stopService(stopIntent)
        NotificationManagerCompat.from(context).cancelAll()
    }

    private fun actionIntent(
        context: Context,
        action: String,
        value: String,
        notificationId: Int
    ): PendingIntent {
        val intent = Intent(context, NotificationActionReceiver::class.java).apply {
            this.action = action
            putExtra(EXTRA_VALUE, value)
            putExtra(EXTRA_NOTIFICATION_ID, notificationId)
        }

        return PendingIntent.getBroadcast(
            context,
            (notificationId xor action.hashCode()),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun extractValue(intent: Intent): String? =
        intent.getStringExtra(EXTRA_VALUE)
}
