package com.example.totpshare

import android.content.Intent
import android.net.Uri
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

data class ParsedTotp(
    val serviceName: String,
    val secret: String,
    val source: String
)

object IntentHandler {

    fun parse(intent: Intent): ParsedTotp? {
        val text = intent.getStringExtra(Intent.EXTRA_TEXT)?.trim() ?: return null
        return parseText(text)
    }

    fun parseText(input: String): ParsedTotp? {
        val text = input.trim()

        if (text.startsWith("otpauth://totp/", ignoreCase = true)) {
            return parseOtpAuth(text)
        }

        val secret = TotpGenerator.cleanBase32(text)
        if (TotpGenerator.isValidBase32(secret)) {
            return ParsedTotp(
                serviceName = "2FA Code",
                secret = secret,
                source = secret
            )
        }

        return null
    }

    private fun parseOtpAuth(uriText: String): ParsedTotp? {
        val uri = try {
            Uri.parse(uriText)
        } catch (_: Exception) {
            return null
        }

        if (!uri.scheme.equals("otpauth", ignoreCase = true) ||
            !uri.host.equals("totp", ignoreCase = true)
        ) return null

        val secret = uri.getQueryParameter("secret")
            ?.let(TotpGenerator::cleanBase32)
            ?: return null

        if (!TotpGenerator.isValidBase32(secret)) return null

        val label = try {
            URLDecoder.decode(
                uri.path?.removePrefix("/") ?: "",
                StandardCharsets.UTF_8.name()
            )
        } catch (_: Exception) {
            uri.path?.removePrefix("/") ?: ""
        }

        val issuer = uri.getQueryParameter("issuer")?.trim().orEmpty()
        val service = when {
            issuer.isNotEmpty() -> issuer
            label.contains(":") -> label.substringBefore(":").trim()
            label.isNotBlank() -> label
            else -> "Shared Account"
        }

        return ParsedTotp(
            serviceName = service.ifBlank { "Shared Account" },
            secret = secret,
            source = uriText
        )
    }
}
