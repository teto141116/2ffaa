package com.example.totpshare

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast

class NotificationActionReceiver : android.content.BroadcastReceiver() {

    override fun onReceive(context: Context, intent: android.content.Intent) {
        val value = AppNotificationManager.extractValue(intent) ?: return

        val clipboard =
            context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

        val label = if (intent.action == AppNotificationManager.ACTION_COPY_CODE) {
            "TOTP code"
        } else {
            "TOTP source"
        }

        clipboard.setPrimaryClip(ClipData.newPlainText(label, value))

        Toast.makeText(
            context,
            if (intent.action == AppNotificationManager.ACTION_COPY_CODE)
                "تم نسخ الرمز"
            else
                "تم نسخ المفتاح / الرابط",
            Toast.LENGTH_SHORT
        ).show()
    }
}
