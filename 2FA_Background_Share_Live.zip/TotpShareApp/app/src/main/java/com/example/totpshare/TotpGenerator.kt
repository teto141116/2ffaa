package com.example.totpshare

import android.util.Base64
import java.nio.ByteBuffer
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.math.pow

object TotpGenerator {

    fun generate(secret: String, timeMillis: Long = System.currentTimeMillis()): String {
        val key = decodeBase32(secret)
        val counter = timeMillis / 1000L / 30L

        val data = ByteBuffer.allocate(8).putLong(counter).array()
        val mac = Mac.getInstance("HmacSHA1")
        mac.init(SecretKeySpec(key, "HmacSHA1"))
        val hash = mac.doFinal(data)

        val offset = hash[hash.lastIndex].toInt() and 0x0F
        val binary =
            ((hash[offset].toInt() and 0x7F) shl 24) or
            ((hash[offset + 1].toInt() and 0xFF) shl 16) or
            ((hash[offset + 2].toInt() and 0xFF) shl 8) or
            (hash[offset + 3].toInt() and 0xFF)

        val otp = binary % 10.0.pow(6).toInt()
        return otp.toString().padStart(6, '0')
    }

    fun isValidBase32(secret: String): Boolean {
        return try {
            val clean = cleanBase32(secret)
            clean.length >= 16 && decodeBase32(clean).isNotEmpty()
        } catch (_: Exception) {
            false
        }
    }

    fun cleanBase32(value: String): String =
        value.uppercase().filter { it in 'A'..'Z' || it in '2'..'7' }

    private fun decodeBase32(value: String): ByteArray {
        val clean = cleanBase32(value)
        require(clean.isNotEmpty()) { "Empty secret" }

        val output = ByteArray(clean.length * 5 / 8)
        var buffer = 0
        var bitsLeft = 0
        var outIndex = 0

        for (ch in clean) {
            val v = when (ch) {
                in 'A'..'Z' -> ch.code - 'A'.code
                in '2'..'7' -> ch.code - '2'.code + 26
                else -> throw IllegalArgumentException("Invalid Base32")
            }

            buffer = (buffer shl 5) or v
            bitsLeft += 5

            if (bitsLeft >= 8) {
                bitsLeft -= 8
                output[outIndex++] = (buffer shr bitsLeft).toByte()
            }
        }

        return if (outIndex == output.size) output else output.copyOf(outIndex)
    }
}
