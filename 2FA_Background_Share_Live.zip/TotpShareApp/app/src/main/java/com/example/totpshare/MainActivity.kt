package com.example.totpshare

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.Switch
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var store: AccountStore
    private lateinit var settings: AppSettings
    private var accounts by mutableStateOf(emptyList<TotpAccount>())
    private var enabled by mutableStateOf(true)
    private var input by mutableStateOf("")

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        store = AccountStore(this)
        settings = AppSettings(this)
        enabled = settings.isEnabled()
        AppNotificationManager.createChannel(this)
        accounts = store.getAll()

        if (enabled) requestNotificationPermissionIfNeeded()
        handleIncomingIntent(intent)

        setContent {
            MaterialTheme {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "eMaD 2FA",
                                style = MaterialTheme.typography.headlineSmall
                            )
                            Text(
                                text = if (enabled) "ON — استقبال الأكواد والتوليد يعمل" else "OFF — التطبيق متوقف تماماً",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }

                        Switch(
                            checked = enabled,
                            onCheckedChange = { newEnabled ->
                                enabled = newEnabled
                                settings.setEnabled(newEnabled)
                                if (!newEnabled) {
                                    AppNotificationManager.stopLive(this@MainActivity)
                                }
                                // Recompose this screen with the persisted setting.
                                accounts = store.getAll()
                            }
                        )
                    }

                    OutlinedTextField(
                        value = input,
                        enabled = enabled,
                        onValueChange = { input = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("مفتاح Base32 أو رابط otpauth://") },
                        minLines = 2
                    )

                    Button(
                        enabled = enabled,
                        onClick = {
                            val parsed = IntentHandler.parseText(input)
                            if (parsed != null) {
                                saveAndNotify(parsed)
                                input = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("إضافة وتوليد الرمز")
                    }

                    Text(
                        text = "الحسابات المحفوظة",
                        style = MaterialTheme.typography.titleMedium
                    )

                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(accounts, key = { it.id }) { account ->
                            AccountRow(
                                account = account,
                                appEnabled = enabled,
                                onDelete = {
                                    store.delete(account.id)
                                    accounts = store.getAll()
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent) {
        if (!enabled) return
        if (intent.action != Intent.ACTION_SEND) return

        val parsed = IntentHandler.parse(intent) ?: return
        saveAndNotify(parsed)
    }

    private fun saveAndNotify(parsed: ParsedTotp) {
        if (!enabled) return
        store.add(
            TotpAccount(
                id = System.currentTimeMillis(),
                name = parsed.serviceName,
                secret = parsed.secret,
                source = parsed.source
            )
        )
        accounts = store.getAll()
        AppNotificationManager.show(this, parsed)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}

@androidx.compose.runtime.Composable
private fun AccountRow(
    account: TotpAccount,
    appEnabled: Boolean,
    onDelete: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = account.name,
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = if (appEnabled) TotpGenerator.generate(account.secret) else "••••••",
                    style = MaterialTheme.typography.headlineMedium
                )
            }

            TextButton(onClick = onDelete) {
                Text("حذف")
            }
        }
    }
}
