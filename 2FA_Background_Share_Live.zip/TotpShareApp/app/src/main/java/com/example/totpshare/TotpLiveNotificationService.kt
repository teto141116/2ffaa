package com.example.totpshare

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class TotpLiveNotificationService : Service() {

    companion object {
        const val ACTION_START = "com.example.totpshare.START_LIVE"
        const val ACTION_STOP = "com.example.totpshare.STOP_LIVE"

        private const val EXTRA_NAME = "name"
        private const val EXTRA_SECRET = "secret"
        private const val EXTRA_SOURCE = "source"
        private const val NOTIFICATION_ID = 7001
    }

    private val handler = Handler(Looper.getMainLooper())
    private var serviceName = "TOTP"
    private var secret = ""
    private var source = ""

    private val updater = object : Runnable {
        override fun run() {
            if (secret.isNotBlank()) {
                updateNotification()
                handler.postDelayed(this, 1000L)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        AppNotificationManager.createChannel(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                serviceName = intent.getStringExtra(EXTRA_NAME) ?: "TOTP"
                secret = intent.getStringExtra(EXTRA_SECRET) ?: ""
                source = intent.getStringExtra(EXTRA_SOURCE) ?: ""

                if (secret.isNotBlank()) {
                    startForeground(NOTIFICATION_ID, buildNotification())
                    handler.removeCallbacks(updater)
                    handler.post(updater)
                }
            }

            ACTION_STOP -> {
                stopLive()
            }
        }

        return START_STICKY
    }

    private fun updateNotification() {
        NotificationManagerCompat.from(this)
            .notify(NOTIFICATION_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val code = TotpGenerator.generate(secret)
        val secondsLeft = 30L - ((System.currentTimeMillis() / 1000L) % 30L)

        val copyCode = actionIntent(
            AppNotificationManager.ACTION_COPY_CODE,
            code
        )

        val copySource = actionIntent(
            AppNotificationManager.ACTION_COPY_SOURCE,
            source
        )

        return NotificationCompat.Builder(this, AppNotificationManager.CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(serviceName)
            .setContentText("$code  •  ${secondsLeft}s")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("$code\nيتجدد تلقائياً • متبقي $secondsLeft ثانية")
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(
                android.R.drawable.ic_menu_save,
                "نسخ الرمز",
                copyCode
            )
            .addAction(
                android.R.drawable.ic_menu_share,
                "نسخ المفتاح / الرابط",
                copySource
            )
            .build()
    }

    private fun actionIntent(action: String, value: String): PendingIntent {
        val intent = Intent(this, NotificationActionReceiver::class.java).apply {
            this.action = action
            putExtra("value", value)
        }

        return PendingIntent.getBroadcast(
            this,
            action.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun stopLive() {
        handler.removeCallbacksAndMessages(null)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
