package com.example.totpshare

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

class TotpLiveNotificationService : Service() {

    companion object {
        const val ACTION_START = "com.example.totpshare.START_LIVE"
        const val ACTION_STOP = "com.example.totpshare.STOP_LIVE"

        private const val EXTRA_NAME = "name"
        private const val EXTRA_SECRET = "secret"
        private const val EXTRA_SOURCE = "source"
        private const val NOTIFICATION_ID = 7001

        // Check frequently in the background, but notify only when the displayed
        // second actually changes. This keeps the countdown smooth without
        // spamming Android with redundant notification updates.
        private const val TICK_MS = 200L
    }

    private var scheduler: ScheduledExecutorService? = null
    @Volatile private var serviceName = "TOTP"
    @Volatile private var secret = ""
    @Volatile private var source = ""
    @Volatile private var lastShownSecond = Long.MIN_VALUE

    override fun onCreate() {
        super.onCreate()
        AppNotificationManager.createChannel(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                if (!AppSettings(this).isEnabled()) {
                    stopLive()
                    return START_NOT_STICKY
                }

                serviceName = intent.getStringExtra(EXTRA_NAME) ?: "TOTP"
                secret = intent.getStringExtra(EXTRA_SECRET) ?: ""
                source = intent.getStringExtra(EXTRA_SOURCE) ?: ""

                if (secret.isNotBlank()) {
                    lastShownSecond = Long.MIN_VALUE

                    // Put the foreground notification up immediately, then let
                    // the background scheduler keep its countdown synchronized
                    // with the real wall-clock second.
                    startForeground(NOTIFICATION_ID, buildNotification())
                    startPreciseUpdater()
                }
            }

            ACTION_STOP -> stopLive()
        }

        return START_STICKY
    }

    private fun startPreciseUpdater() {
        scheduler?.shutdownNow()

        scheduler = Executors.newSingleThreadScheduledExecutor { runnable ->
            Thread(runnable, "eMaD-2FA-Timer").apply { isDaemon = true }
        }

        // A short fixed tick prevents a delayed UI/main-thread callback from
        // making the notification countdown appear frozen. We derive the
        // displayed value from current wall-clock time, so a delayed tick can
        // never make the timer drift behind reality.
        scheduler?.scheduleAtFixedRate({
            if (!AppSettings(this).isEnabled() || secret.isBlank()) {
                stopLive()
                return@scheduleAtFixedRate
            }

            val currentSecond = System.currentTimeMillis() / 1000L
            if (currentSecond != lastShownSecond) {
                lastShownSecond = currentSecond
                updateNotification()
            }
        }, 0L, TICK_MS, TimeUnit.MILLISECONDS)
    }

    private fun updateNotification() {
        NotificationManagerCompat.from(this)
            .notify(NOTIFICATION_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val code = TotpGenerator.generate(secret)
        val secondsIntoPeriod = (System.currentTimeMillis() / 1000L) % 30L
        val secondsLeft = 30L - secondsIntoPeriod

        val copyCode = actionIntent(
            AppNotificationManager.ACTION_COPY_CODE,
            code
        )

        val copySource = actionIntent(
            AppNotificationManager.ACTION_COPY_SOURCE,
            source
        )

        return NotificationCompat.Builder(this, AppNotificationManager.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_emad2fa)
            .setContentTitle(serviceName)
            .setContentText("$code  •  ${secondsLeft}s")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("$code\nيتجدد تلقائياً • متبقي $secondsLeft ثانية")
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(
                android.R.drawable.ic_menu_save,
                "نسخ الرمز",
                copyCode
            )
            .addAction(
                android.R.drawable.ic_menu_share,
                "نسخ المفتاح",
                copySource
            )
            .build()
    }

    private fun actionIntent(action: String, value: String): PendingIntent {
        val intent = Intent(this, NotificationActionReceiver::class.java).apply {
            this.action = action
            putExtra("value", value)
        }

        return PendingIntent.getBroadcast(
            this,
            action.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun stopLive() {
        scheduler?.shutdownNow()
        scheduler = null
        lastShownSecond = Long.MIN_VALUE
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        scheduler?.shutdownNow()
        scheduler = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
