package com.example.totpshare

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class TotpAccount(
    val id: Long,
    val name: String,
    val secret: String,
    val source: String
)

class AccountStore(context: Context) {
    private val prefs =
        context.getSharedPreferences("totp_accounts", Context.MODE_PRIVATE)

    fun getAll(): List<TotpAccount> {
        val json = prefs.getString("accounts", "[]") ?: "[]"
        val array = JSONArray(json)
        return buildList {
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                add(
                    TotpAccount(
                        id = o.getLong("id"),
                        name = o.getString("name"),
                        secret = o.getString("secret"),
                        source = o.getString("source")
                    )
                )
            }
        }
    }

    fun add(account: TotpAccount) {
        val accounts = getAll().filterNot { it.secret == account.secret }.toMutableList()
        accounts.add(0, account)
        save(accounts)
    }

    fun delete(id: Long) {
        save(getAll().filterNot { it.id == id })
    }

    private fun save(accounts: List<TotpAccount>) {
        val array = JSONArray()
        accounts.forEach {
            array.put(
                JSONObject().apply {
                    put("id", it.id)
                    put("name", it.name)
                    put("secret", it.secret)
                    put("source", it.source)
                }
            )
        }
        prefs.edit().putString("accounts", array.toString()).apply()
    }
}
