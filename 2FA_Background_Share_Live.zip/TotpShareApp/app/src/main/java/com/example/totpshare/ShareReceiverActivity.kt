package com.example.totpshare

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle

/**
 * No-UI Share Target.
 *
 * Receives shared text exactly as before, and also accepts shared images.
 * For an image, the QR code is decoded locally and its otpauth payload is
 * passed through the same TOTP/account/notification flow used for text.
 */
class ShareReceiverActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleShare()
    }

    private fun handleShare() {
        // OFF means absolutely nothing happens to shared input.
        if (!AppSettings(this).isEnabled()) {
            finish()
            return
        }

        val shareIntent = intent ?: run {
            finish()
            return
        }

        if (shareIntent.action != Intent.ACTION_SEND) {
            finish()
            return
        }

        // Keep the existing text-share behavior unchanged.
        IntentHandler.parse(shareIntent)?.let {
            saveAndStart(it)
            return
        }

        // New behavior: accept a shared QR-code image.
        val imageUri = extractSharedImageUri(shareIntent)
        if (imageUri == null) {
            finish()
            return
        }

        QrImageProcessor.process(this, imageUri) { parsed ->
            if (parsed != null) {
                saveAndStart(parsed)
            } else {
                finish()
            }
        }
    }

    private fun extractSharedImageUri(intent: Intent): Uri? {
        val stream = intent.getParcelableExtraCompat<Uri>(Intent.EXTRA_STREAM)
        if (stream != null) return stream

        val clipData = intent.clipData
        if (clipData != null) {
            for (i in 0 until clipData.itemCount) {
                val uri = clipData.getItemAt(i).uri
                if (uri != null) return uri
            }
        }

        return null
    }

    private inline fun <reified T : android.os.Parcelable> Intent.getParcelableExtraCompat(
        key: String
    ): T? = if (android.os.Build.VERSION.SDK_INT >= 33) {
        getParcelableExtra(key, T::class.java)
    } else {
        @Suppress("DEPRECATION")
        getParcelableExtra(key)
    }

    private fun saveAndStart(parsed: ParsedTotp) {
        if (!AppSettings(this).isEnabled()) {
            finish()
            return
        }

        val store = AccountStore(this)
        store.add(
            TotpAccount(
                id = System.currentTimeMillis(),
                name = parsed.serviceName,
                secret = parsed.secret,
                source = parsed.source
            )
        )

        // Start the exact same live notification flow used by shared text.
        val serviceIntent = Intent(this, TotpLiveNotificationService::class.java).apply {
            action = TotpLiveNotificationService.ACTION_START
            putExtra("name", parsed.serviceName)
            putExtra("secret", parsed.secret)
            putExtra("source", parsed.secret)
        }

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }

        finish()
    }
}
