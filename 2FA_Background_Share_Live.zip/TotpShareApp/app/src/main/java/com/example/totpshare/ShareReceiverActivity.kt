package com.example.totpshare

import android.app.Activity
import android.os.Bundle

/**
 * No-UI Share Target.
 *
 * Android launches this tiny Activity when the user selects 2FA from the
 * Share Sheet. It never renders a screen: it processes the shared text,
 * starts the Live TOTP notification service, then finishes immediately.
 */
class ShareReceiverActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        handleShare()
        finish()
    }

    private fun handleShare() {
        if (intent?.action != android.content.Intent.ACTION_SEND) return

        val parsed = IntentHandler.parse(intent) ?: return
        val store = AccountStore(this)

        store.add(
            TotpAccount(
                id = System.currentTimeMillis(),
                name = parsed.serviceName,
                secret = parsed.secret,
                source = parsed.source
            )
        )

        // Start the live notification without opening the main UI.
        val serviceIntent =
            android.content.Intent(this, TotpLiveNotificationService::class.java).apply {
                action = TotpLiveNotificationService.ACTION_START
                putExtra("name", parsed.serviceName)
                putExtra("secret", parsed.secret)
                putExtra("source", parsed.source)
            }

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }
}
